<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {
    public function __construct()
    {
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->output->set_header('Last-Modified:'.gmdate('D, d M Y H:i:s').'GMT');
        $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
        $this->output->set_header('Pragma: no-cache');
        $this->output->set_header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
        $this->Sesi->is_logged();  
    }

	public function index()
	{
		$page 						= $this->input->get('p');
		$data['page_active'] 	= $page;
		$this->load->view('dashboard', $data);
	}

	public function get_form_config($value='')
	{
		$data['config']	= $this->Query->select_where('config', array('*'), array(),0,1,'id ASC')->row();
		$this->load->view('dashboard/Config_desa',$data);
	}

	public function get_form_user($value='')
	{
		$this->load->view('dashboard/User_operator');
	}

	public function update_config()
	{
		$this->form_validation->set_rules('desa_kode','', 'required|trim|numeric');
		$this->form_validation->set_rules('sistem','', 'required|trim');
		$this->form_validation->set_rules('dig_no_und','', 'required|trim|numeric');
		if($this->form_validation->run()==true){
			$desa_kode 				= $this->input->post('desa_kode');
			$sistem 					= $this->input->post('sistem');
			$dig_no_und 			= $this->input->post('dig_no_und');
			$this->Query->updateData('config', array(
													'desa_kode' 		=> $desa_kode,
													'sistem' 			=> $sistem,
													'dig_no_und' 		=> $dig_no_und,
												),
											array(
												'id'	=> 1
											));
			echo json_encode(array('sts'=> true,'msg'=> 'Config berhasil diupdate'));
		}
	}
}

