<?php
defined('BASEPATH') OR exit('No direct script access allowed');
use PhpOffice\PhpSpreadsheet\Spreadsheet;		
class Data_pemilih extends CI_Controller {
    public function __construct()
    {
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->output->set_header('Last-Modified:'.gmdate('D, d M Y H:i:s').'GMT');
        $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
        $this->output->set_header('Pragma: no-cache');
        $this->output->set_header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
        $this->Sesi->is_logged();  
 	}

	public function index()
	{

	}

	public function get_data()
	{
		$limit      = 400;
		$key_search = $this->input->get('key_search');
		$id_dusun   = $this->input->get('id_dusun');
		$rt   		= $this->input->get('rt');
		$field      = '';
		$sort 		= 'data_pemilih.no_urut ASC';
		if(is_numeric($key_search)){
		   $field      = ' data_pemilih.no_urut LIKE "%'.$key_search.'%"';
		   $sort 		= 'data_pemilih.no_urut ASC';
		}else{
			$string = preg_replace('/\s+/', ' ', $key_search);
			if(stripos($string, '-')==TRUE){
				$str 	= explode('-', $string);
				$field      = ' data_pemilih.no_urut >='.$str[0] .' AND data_pemilih.no_urut <=' . $str[1];
				$sort 		= 'data_pemilih.no_urut ASC';
			}else if(stripos($string, ',')==TRUE){
				$field      = ' data_pemilih.no_urut IN ('. $string .')';
				$sort 		= 'data_pemilih.no_urut ASC';
			}else{
				$field      = ' data_pemilih.nama_lengkap LIKE "%'.$key_search.'%"';
				$sort 		= 'data_pemilih.no_urut ASC';
			}
		}

		$filt_dusun      = '';
		if($id_dusun!=100){
		   $filt_dusun      = 'data_pemilih.id_dusun='.$id_dusun .' AND ';
		}

		$filt_rt      = '';
		if($rt!=100 && isset($rt)==true){
		   $filt_rt      = 'data_pemilih.rt='.$rt .' AND ';
		}
		$rekap       = $this->Query->select_where_join2('data_pemilih', 'dusun', 'dusun.uid=data_pemilih.id_dusun', 
		                                        array(
		                                        	'MIN(data_pemilih.no_urut) as start',
		                                        	'MAX(data_pemilih.no_urut) as end',
		                                        	'SUM(IF(data_pemilih.lp=1,1,0)) as jml_lk',
		                                        	'SUM(IF(data_pemilih.lp=2,1,0)) as jml_pr',
		                                        	'COUNT(data_pemilih.id) as total',
		                                        ),
		                                        'data_pemilih.aktif=1  AND '. $filt_dusun . $filt_rt . $field .'',
		                                        0, $limit, $sort)->row();

		$data       = $this->Query->select_where_join2('data_pemilih', 'dusun', 'dusun.uid=data_pemilih.id_dusun', 
		                                        array('data_pemilih.id', 'data_pemilih.no_urut', 'data_pemilih.nik', 'data_pemilih.nama_lengkap', 'data_pemilih.tmp_lahir', 'data_pemilih.tgl_lahir', 'dusun.dusun', 'IF(data_pemilih.lp=1,"L","P") as lp','data_pemilih.rt', 'data_pemilih.rw', 'IF(data_pemilih.sts_nikah=0,"BELUM", IF(data_pemilih.sts_nikah=1,"SUDAH","PERNAH"))as sts_nkh'),
		                                        'data_pemilih.aktif=1  AND '. $filt_dusun . $filt_rt . $field .'',
		                                        0, $limit, $sort);
		$tr_row = '';
		$i      = 1;
		foreach ($data->result_array() as $key => $value) {
			$nik 	= '';
			if($value['nik']!=""){
				$nik 	= '<br>'.$value['nik'];
			}
		   $tr_row .= '<tr id="pemilih'. $value['id'] .'">
								<td><div class="checkbox checkbox-css">
											<input type="checkbox" name="select_urut" class="selected_urut" id="cssCheckbox1'. $value['id'] .'" value="'. $value['id'] .'" checked="">
											<label for="cssCheckbox1'. $value['id'] .'">'. $value['no_urut'] .'</label>
										</div>
								</td>
								<td><b>'.$value['nama_lengkap'] .'</b>'. $nik. '</td>
								<td>'. $value['lp'] .'</td>
								<td>'. $value['dusun'] .'</td>
								<td>'. $value['rt'] .'/'. $value['rw'] .'</td>
								<td>'. $value['sts_nkh'] .'</td>
								</tr>';
		   $i++;
		}

		//<td><b>'. $value['nama_lengkap'] .'</b><br>'.$value['tmp_lahir'] . ', '. $value['tgl_lahir'] .'</td>
		echo json_encode(array('sts'=>true, 'rekap'=> $rekap, 'data'=> $tr_row));
	}

	public function get_data_rt($value='')
	{
		$id_dusun 	= $this->input->get('id_dusun');
		$filter 		= array();
		if($id_dusun!=100){
			$filter = array('id_dusun'=> $id_dusun);
		}
		$data = $this->Query->select_where_group_by('data_pemilih', 
														array('data_pemilih.rt'), 
														array('data_pemilih.rt'),
														$filter, 0, 50, 'rw ASC')->result_array();
		echo json_encode(array('sts'=> true,'data'=> $data));
	}

	public function get_form_dusun()
	{
		$data['dusun']		= $this->Query->select_where('dusun', 
													array('*'), 
													array(), 0,40,'uid ASC');
		$this->load->view('dashboard/data_pemilih/Dusun_form', $data);
	}

	public function get_edit_dusun()
	{
		$id 		= $this->input->get('id_dusun');
		$dusun	= $this->Query->select_where('dusun', array('*'), array('id'=> $id), 0,1,'uid ASC');
		if($dusun->num_rows()>0){
			$data['dusun'] = $dusun->row();
			$this->load->view('dashboard/data_pemilih/Dusun_form_edit', $data);
		}else{
			echo 'Data tidak ditemukan';
		}
	}

	public function update_dusun()
	{
		$this->form_validation->set_rules('id','', 'required|trim|numeric');
		$this->form_validation->set_rules('uid','', 'required|trim|numeric');
		$this->form_validation->set_rules('dusun','', 'required|trim');
		if($this->form_validation->run()==true){
			$id 		= $this->input->post('id');
			$uid 		= $this->input->post('uid');
			$dusun 	= $this->input->post('dusun');
			$this->Query->updateData('dusun', array('uid'=> $uid, 'dusun'=> $dusun), array('id'=> $id));
			$data 	= array('id'=> $id, 'uid'=> $uid, 'dusun'=> '<a href="javascript:void(0)" onclick="get_edit_dusun('.$id.')">'.$dusun.'</a>');
			echo json_encode(array('sts'=> true, 'msg'=> 'Dusun berhasil diperbarui', 'data'=> $data));
		}else{
			echo json_encode(array('sts'=> false, 'msg'=> validation_errors()));
		}
	}

	public function add_new_dusun($value='')
	{
		$this->load->view('dashboard/data_pemilih/Dusun_form_add');
	}

	public function add_new_dusun_action($value='')
	{
		$this->form_validation->set_rules('uid','', 'required|trim|numeric');
		$this->form_validation->set_rules('dusun','', 'required|trim');
		if($this->form_validation->run()==true){
			$uid 		= $this->input->post('uid');
			$dusun 	= $this->input->post('dusun');
			$this->Query->insertData('dusun', array('uid'=> $uid, 'dusun'=> $dusun));
			$dsn	= $this->Query->select_where('dusun', array('id'), array('uid'=> $uid, 'dusun'=> $dusun), 0,1,'id ASC')->row();
			$id 		= $dsn->id;
			$data 	= array('dusun'=> '<tr><td>'.$uid.'</td><td><a href="javascript:void(0)" onclick="get_edit_dusun('.$id.')">'.$dusun.'</a></td></tr>');
			echo json_encode(array('sts'=> true, 'msg'=> 'Dusun berhasil ditambahkan', 'data'=> $data));
		}else{
			echo json_encode(array('sts'=> false, 'msg'=> validation_errors()));
		}
	}

	public function remove_dusun()
	{
		$this->form_validation->set_rules('id_dusun','', 'required|trim|numeric');
		if($this->form_validation->run()==true){
			$id_dusun 	= $this->input->post('id_dusun');
			$this->Query->deleteData('dusun', array('id'=> $id_dusun));
			echo json_encode(array('sts'=> true, 'msg'=> 'Dusun berhasil dihapus'));
		}
	}

	public function print_und_pemilih()
	{
		$id_list 	= $this->input->get('clist');
		$uid 			= $this->session->userdata('uid');
		$margin		= $this->Query->select_where('print_und_setup', array('*'), array('uid_user'=> $uid), 0,1,'id ASC');
		if($margin->num_rows()>0){
			if($id_list!=""){
				$id_list= preg_replace("/-/", ",", $id_list);
				$data['pemilih'] 	= $this->Query->select_where_join2('data_pemilih', 'dusun', 'dusun.uid=data_pemilih.id_dusun', 
				                                        array('data_pemilih.id', 'data_pemilih.no_urut', 'data_pemilih.nik', 'data_pemilih.nama_lengkap', 'data_pemilih.tmp_lahir', 'data_pemilih.tgl_lahir', 'dusun.dusun', 'IF(data_pemilih.lp=1,"L","P") as lp','data_pemilih.rt', 'data_pemilih.rw', 'IF(data_pemilih.sts_nikah=0,"BELUM", IF(data_pemilih.sts_nikah=1,"SUDAH","PERNAH"))as sts_nkh'),
				                                        'data_pemilih.aktif=1 AND data_pemilih.id IN ('. $id_list .')',
				                                        0, 300, 'data_pemilih.no_urut ASC')->result_array();
				$data['margin']	= $this->Query->select_where('print_und_setup', array('*'), array('uid_user'=> $uid), 0,1,'id ASC')->row();
				$this->load->view('dashboard/data_pemilih/print/Und_pemilih', $data);
			}
		}else{
			$default = $this->Query->select_where('print_und_setup', 
													array('*'), 
													array('uid_user'=>0), 0,1,'id ASC')->row();
			$this->Query->insertData('print_und_setup', 
											array(
												'uid_user'			=> $uid,
												'wrap'				=> $default->wrap,
												'no_urut_top'		=> $default->no_urut_top,
												'nama_pemilih'		=> $default->nama_pemilih,
												'alamat_pemilih'	=> $default->alamat_pemilih,
												'alamat_pemilih2'	=> $default->alamat_pemilih2,
												'no_urut_bottom'	=> $default->no_urut_bottom,
											));
			$this->print_und_pemilih();
		}
	}

	public function print_und_pemilih_tes()
	{
		$uid 			= $this->session->userdata('uid');
		$data['margin']	= $this->Query->select_where('print_und_setup', array('*'), array('uid_user'=> $uid), 0,1,'id ASC')->row();
		$this->load->view('dashboard/data_pemilih/print/Und_pemilih_tes', $data);
	}

	public function get_setup_print_und()
	{
		$uid 		= $this->session->userdata('uid');
		$setup 	= $this->Query->select_where('print_und_setup', 
													array('*'), 
													array('uid_user'=> $uid), 0,1,'id ASC');
		if($setup->num_rows()>0){
			$data['margin'] = $setup->row();
		}else{
			$default = $this->Query->select_where('print_und_setup', 
													array('*'), 
													array('uid_user'=>0), 0,1,'id ASC')->row();
			$this->Query->insertData('print_und_setup', 
											array(
												'uid_user'			=> $uid,
												'wrap'				=> $default->wrap,
												'no_urut_top'		=> $default->no_urut_top,
												'nama_pemilih'		=> $default->nama_pemilih,
												'alamat_pemilih'	=> $default->alamat_pemilih,
												'alamat_pemilih2'	=> $default->alamat_pemilih2,
												'no_urut_bottom'	=> $default->no_urut_bottom,
											));
			$this->get_setup_print_und();
		}
		$this->load->view('dashboard/data_pemilih/print/Setup_und', $data);
	}

	public function setting_print_und_save()
	{
		$this->form_validation->set_rules('no_urut_top_top','', 'required|trim|numeric');
		$this->form_validation->set_rules('no_urut_top_left','', 'required|trim|numeric');
		$this->form_validation->set_rules('no_urut_top_font_size','', 'required|trim|numeric');
		$this->form_validation->set_rules('nama_pemilih_top','', 'required|trim|numeric');
		$this->form_validation->set_rules('nama_pemilih_left','', 'required|trim|numeric');
		$this->form_validation->set_rules('nama_pemilih_font_size','', 'required|trim|numeric');
		$this->form_validation->set_rules('alamat_pemilih_top','', 'required|trim|numeric');
		$this->form_validation->set_rules('alamat_pemilih_left','', 'required|trim|numeric');
		$this->form_validation->set_rules('alamat_pemilih_font_size','', 'required|trim|numeric');
		$this->form_validation->set_rules('alamat_pemilih2_top','', 'required|trim|numeric');
		$this->form_validation->set_rules('alamat_pemilih2_left','', 'required|trim|numeric');
		$this->form_validation->set_rules('alamat_pemilih2_font_size','', 'required|trim|numeric');
		$this->form_validation->set_rules('no_urut_bottom_top','', 'required|trim|numeric');
		$this->form_validation->set_rules('no_urut_bottom_left','', 'required|trim|numeric');
		$this->form_validation->set_rules('no_urut_bottom_font_size','', 'required|trim|numeric');

		if($this->form_validation->run()==true){
			$no_urut_top_top 				= $this->input->post('no_urut_top_top');
			$no_urut_top_left 			= $this->input->post('no_urut_top_left');
			$no_urut_top_font_size 		= $this->input->post('no_urut_top_font_size');
			$nama_pemilih_top  			= $this->input->post('nama_pemilih_top');
			$nama_pemilih_left			= $this->input->post('nama_pemilih_left');
			$nama_pemilih_font_size		= $this->input->post('nama_pemilih_font_size');
			$alamat_pemilih_top 			= $this->input->post('alamat_pemilih_top');
			$alamat_pemilih_left 		= $this->input->post('alamat_pemilih_left');
			$alamat_pemilih_font_size 	= $this->input->post('alamat_pemilih_font_size');
			$alamat_pemilih2_top 		= $this->input->post('alamat_pemilih2_top');
			$alamat_pemilih2_left 		= $this->input->post('alamat_pemilih2_left');
			$alamat_pemilih2_font_size = $this->input->post('alamat_pemilih2_font_size');
			$no_urut_bottom_top 			= $this->input->post('no_urut_bottom_top');
			$no_urut_bottom_left 		= $this->input->post('no_urut_bottom_left');
			$no_urut_bottom_font_size 	= $this->input->post('no_urut_bottom_font_size');

			$no_urut_top 				= $no_urut_top_top .','.$no_urut_top_left.','.$no_urut_top_font_size;
			$nama_pemilih  			= $nama_pemilih_top .','.$nama_pemilih_left.','.$nama_pemilih_font_size;
			$alamat_pemilih 			= $alamat_pemilih_top .','.$alamat_pemilih_left.','.$alamat_pemilih_font_size;
			$alamat_pemilih2 			= $alamat_pemilih2_top .','.$alamat_pemilih2_left.','.$alamat_pemilih2_font_size;
			$no_urut_bottom 			= $no_urut_bottom_top .','.$no_urut_bottom_left.','.$no_urut_bottom_font_size;

			$this->Query->updateData('print_und_setup', 
											array(
													'no_urut_top' => $no_urut_top,
													'nama_pemilih' => $nama_pemilih,
													'alamat_pemilih' => $alamat_pemilih,
													'alamat_pemilih2' => $alamat_pemilih2,
													'no_urut_bottom' => $no_urut_bottom,
													), 
											array('uid_user'=> $this->session->userdata('uid')));
			echo json_encode(array('sts'=> true));
		}
	}

	// file upload functionality
 	public function upload() {
      // If file uploaded
      if(!empty($_FILES['file']['name'])) { 
      	// get file extension
      	$extension = pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);

      	if($extension == 'csv'){
				$reader = new \PhpOffice\PhpSpreadsheet\Reader\Csv();
			} elseif($extension == 'xlsx') {
				$reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
			} else {
				$reader = new \PhpOffice\PhpSpreadsheet\Reader\Xls();
			}
			// file path
			$spreadsheet = $reader->load($_FILES['file']['tmp_name']);
			$allDataInSheet = $spreadsheet->getActiveSheet()->toArray(null, true, true, true);
			$tr_row='';

			$dusun = $this->Query->select_where('dusun', array('*'), array(),0,20, 'uid ASC')->result_array();

			foreach ($allDataInSheet as $key => $value) {
				if($allDataInSheet[$key]['J']!=""){
					$cek = $this->Query->select_where('data_pemilih', array('id'), array('no_urut'=> $allDataInSheet[$key]['J']), 0,1,'id ASC');
					if($cek->num_rows()<=0){
						if($key>=10){

							$dsn = '<span class="text-danger">error</span>';
							$tgl_lahir = '';
							$lp=1;
							foreach ($dusun as $ky =>  $row) {
								if($row['uid']==$allDataInSheet[$key]['E']){
									$dsn = $row['dusun'];

									//07/09/1975;
									$lp=1;
									if($allDataInSheet[$key]['D']==1){
										$lp=2;
									}

									$nik ='';
									if($allDataInSheet[$key]['K']!=""){
										$nik = $allDataInSheet[$key]['K'];
									}

									$tgl = substr($allDataInSheet[$key]['C'], 3,2);
									$bln = substr($allDataInSheet[$key]['C'], 0,2);
									$thn = substr($allDataInSheet[$key]['C'], 6,4);
									$tgl_lahir = $thn."/".$bln."/".$tgl;

									$this->Query->insertData('data_pemilih', array(
																					'no_urut'		=> $allDataInSheet[$key]['J'],
																					'nama_lengkap' => $allDataInSheet[$key]['B'],
																					'lp' 				=> $lp,
																					'id_dusun' 		=> $allDataInSheet[$key]['E'],
																					'rt' 				=> $allDataInSheet[$key]['G'],
																					'rw' 				=> $allDataInSheet[$key]['F'],
																					'sts_nikah' 	=> $allDataInSheet[$key]['H'],
																					'nik'				=> $nik,
																				));
								}
							}

							$gender="L";
							if($allDataInSheet[$key]['D']==1){
								$gender="P";
							}

							//status nikah
							$sts_nikah= '';
							if($allDataInSheet[$key]['H']==1){
								$sts_nikah= 'Sudah';
							}else if($allDataInSheet[$key]['H']==2){
								$sts_nikah= 'Pernah';
							}else {
								$sts_nikah= 'Belum';
							}
										
							$tr_row .= '<tr>
											<td><div class="checkbox checkbox-css">
													<input type="checkbox" name="select_urut" class="selected_urut" id="cssCheckbox1'.$allDataInSheet[$key]['J'] .'" value="'. $allDataInSheet[$key]['J'] .'" checked="">
													<label for="cssCheckbox1'. $allDataInSheet[$key]['J'] .'">'. $allDataInSheet[$key]['J'] .'</label>
												</div></td>
											<td><b>'. $allDataInSheet[$key]['B'] .'</b></td>
											<td>'. $gender .'</td>
											<td>'. $dsn .'</td>
											<td>'. $allDataInSheet[$key]['F'] .'/'. $allDataInSheet[$key]['G'] .'</td>
											<td>'. $sts_nikah .'</td>
											</tr>';
						}
					}
				}
			}

			echo $tr_row;
			
     	}              
 	}

	// file upload functionality
 	public function upload_v2() {
      // If file uploaded
      if(!empty($_FILES['file']['name'])) { 
      	// get file extension
      	$extension = pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);

      	if($extension == 'csv'){
				$reader = new \PhpOffice\PhpSpreadsheet\Reader\Csv();
			} elseif($extension == 'xlsx') {
				$reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
			} else {
				$reader = new \PhpOffice\PhpSpreadsheet\Reader\Xls();
			}
			// file path
			$spreadsheet = $reader->load($_FILES['file']['tmp_name']);
			$allDataInSheet = $spreadsheet->getActiveSheet()->toArray(null, true, true, true);
			$tr_row='';

			$dusun = $this->Query->select_where('dusun', array('*'), array(),0,20, 'uid ASC')->result_array();

			foreach ($allDataInSheet as $key => $value) {
				if($key>=12){
					$gender="L";
					if($allDataInSheet[$key]['H']==2){
						$gender="P";
					}

					$nik = '';
					if($allDataInSheet[$key]['B']!=""){
						$nik = $allDataInSheet[$key]['B'];
					}

					$dsn = '<span class="text-danger">error</span>';
					foreach ($dusun as $ky =>  $row) {
						if($row['uid']==$allDataInSheet[$key]['I']){
							$dsn = $row['dusun'];
							$this->Query->insertData('data_pemilih', array(
																			'no_urut'		=> $allDataInSheet[$key]['A'],
																			'nik' 			=> $nik,
																			'nama_lengkap' => $allDataInSheet[$key]['C'],
																			'tmp_lahir' 	=> $allDataInSheet[$key]['D'],
																			'tgl_lahir' 	=> $allDataInSheet[$key]['G'] . '/'. $allDataInSheet[$key]['F'].'/'. $allDataInSheet[$key]['E'],
																			'lp' => $allDataInSheet[$key]['H'],
																			'id_dusun' => $allDataInSheet[$key]['I'],
																			'rt' => $allDataInSheet[$key]['J'],
																			'rw' => $allDataInSheet[$key]['K'],
																			'sts_nikah' => $allDataInSheet[$key]['L'],
																		));
						}
					}

					//status nikah
					$sts_nikah= '';
					if($allDataInSheet[$key]['L']==1){
						$sts_nikah= 'Sudah';
					}else if($allDataInSheet[$key]['L']==2){
						$sts_nikah= 'Pernah';
					}else {
						$sts_nikah= 'Belum';
					}
						
					$tr_row .= '<tr>
									<td>'. $allDataInSheet[$key]['A'] .'</td>
									<td>'. $allDataInSheet[$key]['B'] .'</td>
									<td><b>'. $allDataInSheet[$key]['C'] .'</b><br>'. $allDataInSheet[$key]['D'] . ', '. $allDataInSheet[$key]['E'] . '-'. $allDataInSheet[$key]['F'].'-'. $allDataInSheet[$key]['G'] .'</td>
									<td>'. $gender .'</td>
									<td>'. $dsn .'</td>
									<td>'. $allDataInSheet[$key]['J'] .'/'. $allDataInSheet[$key]['K'] .'</td>
									<td>'. $sts_nikah .'</td>
									</tr>';
				}
			}

			echo $tr_row;
			
     	}              
 	}

	// checkFileValidation
    public function checkFileValidation($string) {
      $file_mimes = array('text/x-comma-separated-values', 
      	'text/comma-separated-values', 
      	'application/octet-stream', 
      	'application/vnd.ms-excel', 
      	'application/x-csv', 
      	'text/x-csv', 
      	'text/csv', 
      	'application/csv', 
      	'application/excel', 
      	'application/vnd.msexcel', 
      	'text/plain', 
      	'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
      );
      if(isset($_FILES['fileURL']['name'])) {
			$arr_file = explode('.', $_FILES['fileURL']['name']);
			$extension = end($arr_file);
            if(($extension == 'xlsx' || $extension == 'xls' || $extension == 'csv') && in_array($_FILES['fileURL']['type'], $file_mimes)){
                return true;
            }else{
                $this->form_validation->set_message('checkFileValidation', 'Please choose correct file.');
                return false;
            }
        }else{
            $this->form_validation->set_message('checkFileValidation', 'Please choose a file.');
            return false;
        }
    }

    public function remove_data_pemilih()
    {
		$this->form_validation->set_rules('id_list','', 'required|trim');
		if($this->form_validation->run()==true){
			$id_list 				= $this->input->post('id_list');

			$this->Query->deleteData('data_pemilih', 'id IN ('. $id_list .')');
			$id_list	= explode(',', $id_list);
			echo json_encode(array('sts'=> true, 'msg'=> 'Data berhasil dihapus', 'data'=> $id_list));
		}
    }

    public function get_data_kehadiran_rekap()
    {
    	# code...
    }
}

