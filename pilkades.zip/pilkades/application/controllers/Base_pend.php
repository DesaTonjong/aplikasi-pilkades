<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Base_pend extends CI_Controller {
    public function __construct()
    {
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->output->set_header('Last-Modified:'.gmdate('D, d M Y H:i:s').'GMT');
        $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
        $this->output->set_header('Pragma: no-cache');
        $this->output->set_header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
        $this->Sesi->is_logged();  
    }

	public function index()
	{
		header('location:'.base_url('dashboard?p=base_pend'));
	}

    public function get_data()
    {
        $limit      = $this->input->get('limit');
        $key_search = $this->input->get('key_search');
        $jenis      = $this->input->get('jenis');
        $field      = 'base_penduduk.nama_lengkap';
        if(is_numeric($key_search)){
            $field      = 'base_penduduk.nik';
        }

        if($jenis==0){
            $data       = $this->Query->select_where_join2('base_penduduk', 'base_kk', 'base_kk.no_kk=base_penduduk.no_kk', 
                                                    array('base_kk.no_kk', 'base_kk.unix as unix_kk', 'base_penduduk.unix as unix_pend', 'base_penduduk.nik', 'base_penduduk.lp', 'base_penduduk.nama_lengkap', 'base_penduduk.nama_ayah', 'base_penduduk.nama_ibu', 'base_kk.alamat', 'base_kk.rt', 'base_kk.rw'),
                                                    'base_kk.aktif=1 AND base_penduduk.aktif=1 AND '. $field .' LIKE "%'.$key_search.'%"',
                                                    0, $limit, 'base_penduduk.nama_lengkap ASC');
            $head_col   = 'NIK';
            $field_row  = 'nik';
        }else if($jenis==1){
            $data       = $this->Query->select_where_join2('base_kk', 'base_penduduk', 'base_penduduk.nik=base_kk.nik', 
                                                    array('base_kk.no_kk', 'base_kk.unix as unix_kk', 'base_penduduk.unix as unix_pend', 'base_penduduk.nik', 'base_penduduk.lp', 'base_penduduk.nama_lengkap', 'base_penduduk.nama_ayah', 'base_penduduk.nama_ibu', 'base_kk.alamat', 'base_kk.rt', 'base_kk.rw'),
                                                    'base_kk.aktif=1 AND base_penduduk.aktif=1 AND '. $field .' LIKE "%'.$key_search.'%"',
                                                    0, $limit, 'base_penduduk.nama_lengkap ASC');
            $head_col   = 'NOMOR KK';
            $field_row  = 'nik';
        }
        
        $tr_row = '';
        $i      = 1;
        foreach ($data->result_array() as $key => $value) {
            if($jenis==0){
                $onclick    = 'onclick="get_data_penduduk_info('. "'". $value['unix_pend'] ."'".')"';
            }else if($jenis==1){
                $onclick    = 'onclick="get_data_keluarga('. "'". $value['unix_kk'] ."'". ')"';
            }
            $tr_row .='<tr class="pend'. $value['unix_pend'] .'">
                            <td class="text-center">'. $i .'</td>
                            <td><a href="javascript:;" '. $onclick .'><span class="text-dark">'. $this->nik_space($value[$field_row]) .'</span></a></td>
                            <td><a href="javascript:;" '. $onclick .'><span class="text-dark">'. $value['nama_lengkap'] .'</span></a></td>
                            <td class="text-center">'. $value['lp'] .'</td>
                            <td class="text-center">'. $value['rt'] . '</td>
                            <td class="text-center">'. $value['rw'] .'</td>
                            <td>'. $value['nama_ayah'] .'</td>
                            <td>'. $value['nama_ibu'] .'</td>
                        </tr>';
            $i++;
        }
        echo '<table id="table_pend" class="table table-bordered">
            <thead>
                <th class="text-center" width="10px">NO</th>
                <th width="150px">'.$head_col.'</th>
                <th>NAMA LENGKAP</th>
                <th class="text-center">LP</th>
                <th class="text-center" width="10px">RT</th>
                <th class="text-center" width="10px">RW</th>
                <th>AYAH</th>
                <th>IBU</th>
            </thead>
            <tbody>'.$tr_row.'</tbody>
        </table>';
    }

    public function get_data_keluarga()
    {
        $unix  = $this->input->get('unix');
        $data['kep_kel']   = $this->Query->select_where_join2('base_kk', 'base_penduduk', 'base_penduduk.nik=base_kk.nik', 
                                                            array('base_kk.no_kk', 'base_kk.alamat', 'base_kk.rt', 'base_kk.rw', 'base_penduduk.nama_lengkap'), 
                                                            array('base_kk.unix'=> $unix), 
                                                            0,1, 'base_kk.id ASC');
        if($data['kep_kel']->num_rows()>0){
            $data['data']=$data['kep_kel']->row();
            $data['ang_kel']   = $this->Query->select_where('base_penduduk', array('*'), array('no_kk'=> $data['data']->no_kk), 0,24, 'id ASC');
            $this->load->view('dashboard/base_pend/Data_keluarga_info', $data);
        }else{
            echo 'Data tidak ditemukan';
        }
    }

    public function get_data_penduduk_info()
    {
        $unix  = $this->input->get('unix');
        $data['penduduk']   = $this->Query->select_where_join2('base_penduduk', 'base_kk', 'base_kk.no_kk=base_penduduk.no_kk', 
                                                            array('base_kk.unix as unix_kk', 'base_kk.alamat','base_kk.rt', 'base_kk.rw', 'base_penduduk.*'),
                                                            array('base_penduduk.unix'=> $unix), 
                                                            0,1, 'base_penduduk.id ASC');
        $this->load->view('dashboard/base_pend/Data_penduduk_info', $data);

    }

    public function get_data_penduduk_edit()
    {
        $unix  = $this->input->get('unix');
        $data['penduduk']   = $this->Query->select_where_join2('base_penduduk', 'base_kk', 'base_kk.no_kk=base_penduduk.no_kk', 
                                                            array('base_kk.unix as unix_kk', 'base_kk.alamat','base_kk.rt', 'base_kk.rw', 'base_penduduk.*'),
                                                            array('base_penduduk.unix'=> $unix), 
                                                            0,1, 'base_penduduk.id ASC');
        $data['agama']   = $this->Query->select_where('item_agama', array('*'), array(), 0,24, 'agama ASC');
        $data['pekerjaan']   = $this->Query->select_where('item_pekerjaan', array('*'), array(), 0,90, 'pekerjaan ASC');
        $data['pendidikan']   = $this->Query->select_where('item_pendidikan', array('*'), array(), 0,24, 'pendidikan ASC');
        $data['shdrt']   = $this->Query->select_where('item_shdrt', array('*'), array(), 0,24, 'shdrt ASC');
        $data['status']   = $this->Query->select_where('item_status', array('*'), array(), 0,24, 'status ASC');
        $data['status']   = $this->Query->select_where('item_status', array('*'), array(), 0,24, 'status ASC');
        $data['csrf'] = array(
                'name' => $this->security->get_csrf_token_name(),
                'hash' => $this->security->get_csrf_hash()
        );
        $this->load->view('dashboard/base_pend/Data_penduduk_edit', $data);

    }

    public function update_data_penduduk()
    {
        $this->form_validation->set_rules('unix', 'UNIX ID', 'required|trim');
        $this->form_validation->set_rules('nik', 'NIK', 'required|trim');
        $this->form_validation->set_rules('nama_lengkap', 'Nama Lengkap', 'required|trim');
        $this->form_validation->set_rules('lp', 'Jenis Kelamin', 'required|trim');
        $this->form_validation->set_rules('agama', 'Agama', 'required|trim');
        $this->form_validation->set_rules('tmp_lahir', 'Tempat Lahir', 'required|trim');
        $this->form_validation->set_rules('tgl_lahir', 'Tanggal Lahir', 'required|trim');
        $this->form_validation->set_rules('gdr', 'Golongan Darah', 'required|trim');
        $this->form_validation->set_rules('status', 'Status Nikah', 'required|trim');
        $this->form_validation->set_rules('shdrt', 'SHDRT', 'required|trim');
        $this->form_validation->set_rules('pendidikan', 'Pendidikan', 'required|trim');
        $this->form_validation->set_rules('pekerjaan', 'Pekerjaan', 'required|trim');
        $this->form_validation->set_rules('nama_ayah', 'Nama Ayah', 'required|trim');
        $this->form_validation->set_rules('nama_ibu', 'Nama Ibu', 'required|trim');
        if($this->form_validation->run()==true){
            $unix           = $this->input->post('unix');
            $nik            = $this->input->post('nik');
            $nama_lengkap   = $this->input->post('nama_lengkap');
            $lp             = $this->input->post('lp');
            $agama          = $this->input->post('agama');
            $tmp_lahir      = $this->input->post('tmp_lahir');
            $tgl_lahir      = $this->input->post('tgl_lahir');
            $gdr            = $this->input->post('gdr');
            $status         = $this->input->post('status');
            $shdrt          = $this->input->post('shdrt');
            $pendidikan     = $this->input->post('pendidikan');
            $pekerjaan      = $this->input->post('pekerjaan');
            $nama_ayah      = $this->input->post('nama_ayah');
            $nama_ibu       = $this->input->post('nama_ibu');

            $this->Query->updateData('base_penduduk', array(
                                                            'nik'           => $nik,
                                                            'nama_lengkap'  => $nama_lengkap,
                                                            'lp'            => $lp,
                                                            'agama'         => $agama,
                                                            'tmp_lahir'     => $tmp_lahir,
                                                            'tgl_lahir'     => $tgl_lahir,
                                                            'gdr'           => $gdr,
                                                            'status'        => $status,
                                                            'shdrt'         => $shdrt,
                                                            'pendidikan'    => $pendidikan,
                                                            'pekerjaan'     => $pekerjaan,
                                                            'nama_ayah'     => $nama_ayah,
                                                            'nama_ibu'      => $nama_ibu,
                                                            ),
                                                    array('unix'=> $unix)
                                                );
            echo json_encode(array('sts'=> true, 'msg'=> 'Update data berhasil'));
        }else{
            $data['csrf'] = array(
                    'name' => $this->security->get_csrf_token_name(),
                    'hash' => $this->security->get_csrf_hash()
            );
            echo json_encode(array('sts'=> false, 'msg'=> validation_errors(), 'csrf'=> $data));
        }
    }

    public function get_csrf()
    {
        echo json_encode(array('sts'=> true, 'name' => $this->security->get_csrf_token_name(),
                    'hash' => $this->security->get_csrf_hash()));
    }

    public function remove_data_penduduk()
    {
        echo json_encode(array('sts'=> true, 'msg'=> 'Data berhasil dihapus'));
    }
/*
    public function generate_uid($value='')
    {
        $data   = $this->Query->select_where('base_penduduk',
                                                    array('base_penduduk.*'),
                                                    array(), 
                                                    0,100, 'base_penduduk.id ASC');
        foreach ($data->result_array() as $key => $value) {
            $tgl_lahir  = date_create($value['tgl_lahir']);
            $unix        = date_format($tgl_lahir,"Y").date_format($tgl_lahir,"m").date_format($tgl_lahir,"d").$this->Set->generateNumber(10); 
            $this->Query->updateData('base_penduduk', array('unix'=> $unix), array('id'=> $value['id']));
            echo $unix."<br />";
        }
    }
*/

    function nik_space($nik='')
    {
        $nik    = substr($nik, 0,6) . " " . substr($nik, 6,6) . " " . substr($nik, 12,4);
        return $nik;
    }
}

