<?php 
	if($penduduk->num_rows()>0){
		$data 	= $penduduk->row();
?>
	<div class="row">
		<div class="col-md-4">
		</div>
		<div class="col-md-4">
			<address>NIK<br/>
				  <strong><?php echo $this->Set->nik_space($data->nik);?></strong>
			</address>
			<address>Nama Lengkap<br/>
				  <strong><?php echo $data->nama_lengkap;?></strong>
			</address>
			<address>Tempat/Tanggal. Lahir<br/>
				  <strong><?php echo $data->tmp_lahir .", ".$data->tgl_lahir;?></strong>
			</address>
			<address>Alamat<br/>
				  <strong><?php echo $data->alamat ." RT.:".$data->rt ." /RW.:".$data->rw;?></strong>
			</address>
			<div class="row">
				<div class="col-md-6">
					<address>Jenis Kelamin<br/>
						  <strong><?php if($data->lp=="L"){echo "Laki-Laki";}else{echo "Perempuan";}?></strong>
					</address>
				</div>
				<div class="col-md-6">
					<address>Gol. Darah<br/>
						  <strong><?php echo $data->gdr;?></strong>
					</address>
				</div>
			</div>
			<address>Agama<br/>
				  <strong><?php echo $data->agama;?></strong>
			</address>
			<div>
				<button class="btn btn-default btn-sm" onclick="get_data_penduduk_edit('<?php echo $data->unix;?>')">Edit</button>
				<button class="btn btn-default btn-sm" onclick="get_data_keluarga('<?php echo $data->unix_kk;?>')">Data KK</button>
			</div>
		</div>
		<div class="col-md-4">
			<address>Status Nikah<br/>
				  <strong><?php echo $data->status;?></strong>
			</address>
			<address>SHDRT<br/>
				  <strong><?php echo $data->shdrt;?></strong>
			</address>
			<address>Pendidikan<br/>
				  <strong><?php echo $data->pendidikan;?></strong>
			</address>
			<address>Pekerjaan<br/>
				  <strong><?php echo $data->pekerjaan;?></strong>
			</address>
			<address>Nama Ayah<br/>
				  <strong><?php echo $data->nama_ayah;?></strong>
			</address>
			<address>Nama Ibu<br/>
				  <strong><?php echo $data->nama_ibu;?></strong>
			</address>
		</div>
	</div>
<?php 
	}else{
	echo 'Data tidak ditemukan';
}
?>