<?php 
	if($penduduk->num_rows()>0){
		$data 	= $penduduk->row();
?>
	<form id="form_update_data_penduduk" action="<?php echo base_url('base_pend/update_data_penduduk');?>" method="POST">
<div class="row">
	<div class="col-md-4">
	</div>
		<div class="col-md-4">
			<div class="form-group">
				<label>NIK</label>
				<input type="text" name="nik" class="form-control" value="<?php echo $data->nik;?>">
				<input type="text" name="unix" id="unix_update_pend" class="d-none" value="<?php echo $data->unix;?>">
                <input type="hidden" name="<?php echo $csrf['name'];?>" value="<?php echo $csrf['hash'];?>" />
			</div>
			<div class="form-group">
				<label>Nama Lengkap</label>
				<input type="text" name="nama_lengkap" class="form-control" value="<?php echo $data->nama_lengkap;?>">
			</div>
			<div class="form-group">
				<label>Tempat Tanggal Lahir</label>
				<div class="input-group">
					<input type="text" class="form-control" name="tmp_lahir" placeholder="Tempat Lahir" value="<?php echo $data->tmp_lahir;?>">
					<input type="text" class="form-control" name="tgl_lahir" placeholder="Tanggal Lahir" value="<?php echo $data->tgl_lahir;?>">
				</div>
			</div>
			<div class="form-group">
				<label>Alamat</label>
				<input type="text" name="alamat" class="form-control" disabled="" value="<?php echo $data->alamat ." RT.:".$data->rt ." /RW.:".$data->rw;?>">
			</div>

			<div class="form-group">
				<label>Jenis Kelamin/Gol. Darah</label>
				<div class="input-group">
				<select class="form-control" name="lp">
					<option <?php if($data->lp=="L"){echo 'selected';}?> value="L">Laki-laki</option>
					<option <?php if($data->lp=="P"){echo 'selected';}?> value="P">Perempuan</option>
				</select>
				<input type="text" name="gdr" class="form-control" value="<?php echo $data->gdr;?>">
				</div>
			</div>

			<div class="form-group m-t-10">
				<label>Agama</label>
				<select class="form-control" name="agama">
					<?php foreach ($agama->result_array() as $key => $value) { ?>
						<option <?php if($value['agama']==$data->agama){echo 'selected';}?> value="<?php echo $value['agama'];?>"><?php echo $value['agama'];?></option>
					<?php } ?>
				</select>
			</div>
				<div>
					<button type="button" class="btn btn-default btn-sm" onclick="get_data_penduduk_info('<?php echo $data->unix;?>')">Kembali</button>
					<button type="button" class="btn btn-danger btn-sm" onclick="remove_data_penduduk('<?php echo $data->unix;?>',1)">Hapus</button>
				</div>
		</div>
		<div class="col-md-4">
			<div class="form-group">
				<label>Status Nikah</label>
				<select class="form-control" name="status">
					<?php foreach ($status->result_array() as $key => $value) { ?>
						<option <?php if($value['status']==$data->status){echo 'selected';}?> value="<?php echo $value['status'];?>"><?php echo $value['status'];?></option>
					<?php } ?>
				</select>
			</div>
			<div class="form-group m-t-10">
				<label>SHDRT</label>
				<select class="form-control" name="shdrt">
					<?php foreach ($shdrt->result_array() as $key => $value) { ?>
						<option <?php if($value['shdrt']==$data->shdrt){echo 'selected';}?> value="<?php echo $value['shdrt'];?>"><?php echo $value['shdrt'];?></option>
					<?php } ?>
				</select>
			</div>
			<div class="form-group m-t-10">
				<label>Pendidikan</label>
				<select class="form-control" name="pendidikan">
					<?php foreach ($pendidikan->result_array() as $key => $value) { ?>
						<option <?php if($value['pendidikan']==$data->pendidikan){echo 'selected';}?> value="<?php echo $value['pendidikan'];?>"><?php echo $value['pendidikan'];?></option>
					<?php } ?>
				</select>
			</div>
			<div class="form-group m-t-10">
				<label>Pekerjaan</label>
				<select class="form-control" name="pekerjaan">
					<?php foreach ($pekerjaan->result_array() as $key => $value) { ?>
						<option <?php if($value['pekerjaan']==$data->pekerjaan){echo 'selected';}?> value="<?php echo $value['pekerjaan'];?>"><?php echo $value['pekerjaan'];?></option>
					<?php } ?>
				</select>
			</div>
			<div class="form-group">
				<label>Nama Ayah</label>
				<input type="text" name="nama_ayah" class="form-control" value="<?php echo $data->nama_ayah;?>">
			</div>
			<div class="form-group">
				<label>Nama Ibu</label>
				<input type="text" name="nama_ibu" class="form-control" value="<?php echo $data->nama_ibu;?>">
			</div>
			<div>
				<button type="submit" id="btn_update_data_penduduk" class="btn btn-primary btn-sm pull-right">Update</button>
			</div>
		</div>
</div>
	</form>
<?php 
	}else{
	echo 'Data tidak ditemukan';
}
?>