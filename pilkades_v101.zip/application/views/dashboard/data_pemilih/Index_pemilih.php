<?php 
	$cfg 			= $this->Cfg->get_data();
	$jml_segment 		= $this->uri->total_segments();
	$base_url_int 		= $this->Cfg->int_uri($jml_segment);
?>
<ol class="breadcrumb pull-right">
	<li class="breadcrumb-item"><a href="<?php echo base_url('dashboard?p=dashboard');?>">Dashboard</a></li>
	<li class="breadcrumb-item active">Data Pemilih</li>
</ol>
<h3 class="page-header"><?php echo $cfg['sistem'] . ' '. ucwords(strtolower($cfg['desa'])) . ' Kec. '. ucwords(strtolower($cfg['kec']));?></h3>
<div class="panel panel-inverse panel_data">
	<div class="panel-heading">
		<div class="panel-heading-btn">
			<a href="#ModalForm"  class="btn btn-xs btn-icon btn-circle btn-primary" onclick="show_upload_pemilih()"><i class="fa fa-cloud-upload-alt"></i></a>
			<a href="#ModalForm" class="btn btn-xs btn-icon btn-circle btn-default" title="Data Dusun" data-toggle="modal" onclick="get_form_dusun()"><i class="fas fa-lg fa-fw fa-database"></i></a>
			<a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-default" data-click="panel-expand"><i class="fa fa-expand"></i></a>
		</div>
		<h4 class="panel-title title_panel">Database Pemilih <?php if($pemilih->jml>0) {echo '('.number_format($pemilih->jml).')';}?></h4>
	</div>
	<div class="panel-body panel_data_body">
		<div class="row">
			<div class="col-lg-8 col-md-12">
				<div class="row">
					<div class="col">
						<div class="btn-group">
							<a href="javascript:;" class="btn btn-success" title="Print Undangan" onclick="print_undangan()">Und</a>
							<a href="#" data-toggle="dropdown" class="btn btn-success dropdown-toggle" aria-expanded="false"></a>
							<ul class="dropdown-menu" x-placement="bottom-start" style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(86px, 33px, 0px);">
								<li><a href="#ModalForm" data-toggle="modal" onclick="get_setup_print_und()"><i class="fa fa-cog"></i> Setting Print Undangan</a></li>
								<li><a href="javascript:;" onclick="remove_data_pemilih()"><i class="fa fa-times"></i> Hapus</a></li>
							</ul>
						</div>
						<div class="pull-right">
							<form id="form_data" action="<?php echo $base_url_int.'data_pemilih/get_data';?>" class="form-inline m-b-10">
								<div class="input-group m-r-10">
									<select class="form-control form-control-sm" name="id_dusun" id="id_dusun" title="Dusun">
										<?php foreach ($dusun as $key => $value) { ?>
										<option value="<?php echo $value['uid'];?>"><?php echo $value['dusun'];?></option>
									<?php } ?>
										<option value="100">Semua</option>
									</select>
								</div>
								<div class="input-group m-r-10">
									<select class="form-control form-control-sm" name="rt" title="RT" id="rt_filter">
										<?php foreach ($rt as $key => $value) { ?>
											<option value="<?php echo $value['rt'];?>"><?php echo "RT ".$value['rt'];?></option>
										<?php } ?>
										<option value="100">Semua</option>
									</select>
								</div>
								<div class="input-group">
								  	<input type="text" name="key_search" id="key_search" class="form-control form-control-sm" placeholder="Pencarian" title="Kunci Pencarian">
								  	<div class="input-group-append">
								    	<button type="submit" id="btn_submit"  class="btn btn-primary btn-sm">
								      		<i class="fa fa-search"></i>
								    	</button>
								  </div>
								</div>
							</form>
							<small class="f-s-12 text-grey-darker mt-0 mb-2 pull-right" id="info_rkp_pemilih">Jumlah Pemilih</small>
						</div>
				</div>
				</div>
		<div class="dropzone d-none mb-2" id="upload_data_pemilih"></div>
		<table id="table_data_pemilih" class="table table-primary table-striped table-bordered mt-3">
			<thead>
				<tr>
					<th width="60px"><div class="checkbox checkbox-css">
											<input type="checkbox" id="select_urut_checkbox" value="0" checked=""  onClick="check_uncheck_checkbox(this.checked);">
											<label for="select_urut_checkbox">UND</label>
										</div></th>
					<th>NAMA LENGKAP</th>
					<th>L/P</th>
					<th>DUSUN</th>
					<th>RT/RW</th>
					<th>STS NIKAH</th>
				</tr>
			</thead>
			<tbody>
				
			</tbody>
		</table>
	</div>
	<div class="col-lg-4 col-md-12">
		<table class="table table-striped table-bordered">
			<thead>
				<tr>
					<th>DUSUN</th>
					<th>UND</th>
					<th>Lk</th>
					<th>Pr</th>
					<th>JML</th>
				</tr>
			</thead>
			<tbody>
			<?php foreach ($dusun as $key => $value) { 
					$rekap				= $this->Query->select_where_join2_group_by('data_pemilih', 'dusun', 'dusun.uid=data_pemilih.id_dusun', 
		                                        array('data_pemilih.rw', 'data_pemilih.rt',
		                                        	'MIN(data_pemilih.no_urut) as start',
		                                        	'MAX(data_pemilih.no_urut) as end',
		                                        	'SUM(IF(data_pemilih.lp=1,1,0)) as jml_lk',
		                                        	'SUM(IF(data_pemilih.lp=2,1,0)) as jml_pr',
		                                        	'COUNT(data_pemilih.id) as total',
		                                        ),
		                                        array('data_pemilih.rw', 'data_pemilih.rt'),
		                                        'data_pemilih.aktif=1 AND data_pemilih.id_dusun='.$value['uid'],
		                                        0, 60, 'data_pemilih.id_dusun, data_pemilih.rw, data_pemilih.rt ASC')->result_array();
			?>
				<tr>
					<td colspan="5"><b><?php echo $value['dusun'];?></b></td>
				</tr>
			<?php foreach ($rekap as $ey => $row) { ?>
				<tr>
					<td>&nbsp;&nbsp;&nbsp;<?php echo $row['rt'].'/'.$row['rw'];?></td>
					<td class="text-center"><?php echo $row['start'].'-'.$row['end'];?></td>
					<td class="text-right"><?php echo $row['jml_lk'];?></td>
					<td class="text-right"><?php echo $row['jml_pr'];?></td>
					<td class="text-right"><?php echo $row['total'];?></td>
				</tr>
			<?php } } ?>
			</tbody>
		</table>
	</div>
	</div>
</div>

<div class="modal fade" id="ModalForm">
    <div class="modal-dialog modal-lg modal-dialog-centered">
    	<div class="modal-content">
			<div id="data_content"></div>
		</div>		
  </div>
</div>