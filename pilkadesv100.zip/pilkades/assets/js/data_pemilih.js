Dropzone.autoDiscover = false;
$(document).ready(function(){
	$("#upload_data_pemilih").dropzone({ 
								url: "data_pemilih/upload", 
								paramName: "file",
								maxFilesize: 2, 
							  	success:function(file, response){
								  	$("#table_data_pemilih tbody").empty();
								  	$("#table_data_pemilih tbody").append(response);
							  	}
							});
});
var div_upload_pemilih=0;
function show_upload_pemilih() {
	if(div_upload_pemilih==0){
		div_upload_pemilih=1;
		$(".dropzone").removeClass('d-none');
		$(this).addClass('active');
	}else{
		div_upload_pemilih=0;
		$(".dropzone").addClass('d-none');
		$(this).removeClass('active');
	}
}

get_data();

function get_data() {
	$("#table_data_pemilih tbody").empty();
	var target   = $('.panel_data');
	var id_dusun = $('#id_dusun option:selected').val();
	var rt 			= $('#rt_filter option:selected').val();
	var key_search	= $('#key_search').val();
	if (!$(target).hasClass('panel-loading')) {
		var targetBody = $(target).find('.panel_data_body');
		var spinnerHtml = '<div class="panel-loader"><span class="spinner-small"></span></div>';
		$(target).addClass('panel-loading');
		$(targetBody).prepend(spinnerHtml);
		var form = $("#form_data");
		$.get(base_url+"data_pemilih/get_data", {'id_dusun':id_dusun, 'rt': rt, 'key_search':key_search}, function(json){
			$("#table_data_pemilih tbody").append(json.data);
			$(target).removeClass('panel-loading');
			$(target).find('.panel-loader').remove();

			$("#info_rkp_pemilih").html('Data Pemilih <label class="label label-warning">' + json.rekap.start + '-' + json.rekap.end+ '</label> <label class="label label-success">Lk : '+json.rekap.jml_lk + '</label>  <label class="label label-primary">Pr : ' + json.rekap.jml_pr+ '</label> <label class="label label-inverse">Jumlah : ' + json.rekap.total+ '</label>');
		},'json');
	}
}
$(document).on('click', '[data-click=panel-reload]', function(e) {
	e.preventDefault();
	get_data();
});

$(document).on('submit', '#form_data', function(e) {
	e.preventDefault();
	get_data();
});

function get_data_rt() {
	var id_dusun = $("#id_dusun option:selected").val();
	$.get(base_url+"data_pemilih/get_data_rt", {'id_dusun':id_dusun}, function(json){
		$("#rt_filter").empty();
     	$.each(json.data, function(i) {
         $("#rt_filter").append(new Option("RT "+json.data[i].rt, json.data[i].rt));
     	});
     	$("#rt_filter").append(new Option("Semua...", 100));
	},'json');
}

$(document).on('change', '#id_dusun', function(e) {
	e.preventDefault();
	$("#table_data_pemilih tbody").empty();
	get_data_rt();
});

$(document).on('change', '#rt_filter', function(e) {
	e.preventDefault();
	$("#table_data_pemilih tbody").empty();
	get_data();
});


$(document).ready(function() {
    // Check All
    $('#select_urut_checkbox').click(function() {
        $(":checkbox").attr("checked", true);
    });
    // Uncheck All
    $('#select_urut_checkbox').click(function() {
        $(":checkbox").attr("checked", false);
    });
});

function check_uncheck_checkbox(isChecked) {
	if(isChecked) {
		$('input[name="select_urut"]').each(function() { 
			this.checked = true; 
		});
	} else {
		$('input[name="select_urut"]').each(function() {
			this.checked = false;
		});
	}
}

function get_setup_print_und() {
	$.get(base_url+"data_pemilih/get_setup_print_und", function(data){
			$("#data_content").html(data);
	});
}

function print_undangan() {
	var sList = "";
	$('input[name="select_urut"]').each(function () {
		if(this.checked){
		   sList += "-" + $(this).val();
	 	}
	});
	sList = sList.substring(1);
	var url 			= base_url+"data_pemilih/print_und_pemilih?clist="+sList;
	var page_size 	= "width=900,height=600";
	var popupWin 	= window.open(url, "_blank", page_size);
	popupWin.document.open(url, "_blank", page_size);
	popupWin.document.close();
	popupWin.focus();
   popupWin.print();
}

function get_form_dusun() {
	$.get(base_url+"data_pemilih/get_form_dusun", function(data){
		$("#data_content").html(data);
	});
}

function get_edit_dusun(id_dusun) {
	$.get(base_url+"data_pemilih/get_edit_dusun", {'id_dusun':id_dusun}, function(data){
		$("#edit_form_dusun").html(data);
	});
}

function close_edit_dusun() {
	$("#edit_form_dusun").html('');
}

$(document).on('submit', '#update_dusun', function(e) {
	e.preventDefault();
	var form = $("#update_dusun");
	$.post(base_url+"data_pemilih/update_dusun", form.serialize(),function(json){
		if(json.sts==true){
			$("#uid"+json.data.id).html(json.data.uid);
			$("#dusun"+json.data.id).html(json.data.dusun);
			$("#edit_form_dusun").html('');
		}else{
			//alert
		}
	},'json');
	return false;
});

function add_new_dusun() {
	$.get(base_url+"data_pemilih/add_new_dusun", function(data){
		$("#edit_form_dusun").html(data);
	});
}

$(document).on('submit', '#add_new_dusun', function(e) {
	e.preventDefault();
	var form = $("#add_new_dusun");
	$.post(base_url+"data_pemilih/add_new_dusun_action", form.serialize(),function(json){
		if(json.sts==true){
			$("#table_dusun tbody").prepend(json.data.dusun);
			$("#dusun_edit").val('');
			$("#uid_dusun_edit").val('');
			$("#uid_dusun_edit").focus();
		}else{
			//alert
		}
	},'json');
	return false;
});

function remove_dusun(id_dusun) {
	$.post(base_url+"data_pemilih/remove_dusun", {'id_dusun':id_dusun},function(json){
		if(json.sts==true){
			$("#dsn"+id_dusun).fadeOut();
			$("#edit_form_dusun").html('');
		}else{
			//alert
		}
	},'json');
}

function print_undangan_tes() {
	var sList = "";
	$('input[name="select_urut"]').each(function () {
		if(this.checked){
		   sList += "-" + $(this).val();
	 	}
	});
	sList = sList.substring(1);
	var url 			= base_url+"data_pemilih/print_und_pemilih_tes";
	var page_size 	= "width=900,height=600";
	var popupWin 	= window.open(url, "_blank", page_size);
	popupWin.document.open(url, "_blank", page_size);
	popupWin.document.close();
	popupWin.focus();
   popupWin.print();
}


$(document).on('submit', '#setting_print_und_save', function(e) {
	e.preventDefault();
	var form = $("#setting_print_und_save");
	$.post(base_url+"data_pemilih/setting_print_und_save", form.serialize(),function(json){
	},'json');
	return false;
});

function remove_data_pemilih() {
	var sList = "";
	$('input[name="select_urut"]').each(function () {
		if(this.checked){
		   sList += "," + $(this).val();
	 	}
	});
	sList = sList.substring(1);
	$.post(base_url+"data_pemilih/remove_data_pemilih", {'id_list':sList},function(json){
		if(json.sts==true){
			alert(json.msg);
			$.each(json.data, function (index, value) {
			    $("#pemilih"+value).fadeOut();
			});
		}else{
			alert(json.msg);
		}
	},'json');
}