<?php 
	$cfg 			= $this->Cfg->get_data();
?>
<ol class="breadcrumb pull-right">
	<li class="breadcrumb-item"><a href="javascript:;">Dashboard</a></li>
	<li class="breadcrumb-item active">PILKADES</li>
</ol>
<h4 class="page-header"><?php echo $cfg['sistem'] . ' '. ucwords(strtolower($cfg['desa'])) . ' Kec. '. ucwords(strtolower($cfg['kec']));?></h4>
<div class="panel panel-inverse panel_data">
	<div class="panel-heading">
		<div class="panel-heading-btn">
			<a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-default" data-click="panel-expand"><i class="fa fa-expand"></i></a>
			<a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-success" data-click="panel-reload"><i class="fa fa-redo"></i></a>
			<a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-warning" data-click="panel-collapse"><i class="fa fa-minus"></i></a>
		</div>
		<h4 class="panel-title">PILKADES</h4>
	</div>
	<div class="panel-body panel_data_body" style="min-height: 500px;">

	</div>
</div>

<div class="modal fade" id="ModalForm">
    <div class="modal-dialog modal-lg modal-dialog-centered">
      	<div class="modal-content">
			<div class="panel panel-inverse panel_modal">
				<div class="panel-heading">
					<div class="panel-heading-btn">
						<a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-default" data-click="panel-expand"><i class="fa fa-expand"></i></a>
						<a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-danger " data-dismiss="modal"><i class="fa fa-times"></i></a>
					</div>
					<h4 class="panel-title" id="modal_title"></h4>
				</div>
				<div class="panel-body panel_modal_body">
					<div id="modal_content"></div>
				</div>
			</div>
  		</div>
  </div>
</div>