<?php
?>
	<div class="row">
		<div class="col-md-3">
			<address>Nomor KK<br/>
				  <strong><?php echo $this->Set->nik_space($data->no_kk);?></strong>
			</address>
		</div>
		<div class="col-md-4">
			<address>Kepala Keluarga<br/>
				  <strong><?php echo $data->nama_lengkap;?></strong>
			</address>
		</div>
		<div class="col-md-3">
			<address>Alamat<br/>
				  <strong><?php echo $data->alamat;?></strong>
			</address>
		</div>
		<div class="col-md-2">
			<address>RT/RW<br/>
				  <strong><?php echo $data->rt ." / " .$data->rw;?></strong>
			</address>
		</div>
	</div>
	<table class="table table-bordered">
		<thead>
			<tr>
				<th>NO</th>
				<th>NAMA LENGKAP</th>
				<th>AGAMA</th>
				<th>SHDRT/STATUS</th>
				<th colspan="2">ORANG TUA</th>
			</tr>
		</thead>
		<tbody>
			<?php 
			 	$i=1;
			 	$gdr 	= '';
			 	foreach ($ang_kel->result_array() as $key => $value) {
			 	if($value['gdr']!="Tidak Tahu"){
			 		$gdr 	= $value['gdr'];
			 	} 
			echo '<tr class="pend'. $value['unix'] .'">
				<td>'. $i .'</td>
				<td><a href="javascript:;" onclick="get_data_penduduk_info('. "'". $value['unix'] ."'".')"><b>'. $value['nama_lengkap'] .'</b></a><span class="pull-right">'. $value['lp'] .'</span><br>'. $value['tmp_lahir'] .', '. $value['tgl_lahir'] .'<span class="pull-right">'. $gdr .'</span></td>
				<td>'. $value['agama'] .'</td>
				<td>'. $value['shdrt'] .'<span class="pull-right">'. $value['status'] .'</span><br>'. $value['pekerjaan'] .'</td>
				<td>'. $value['nama_ayah'] .'<br>'. $value['nama_ibu'] .'</td>
				<td><a href="javascript:;" onclick="remove_data_penduduk('. "'". $value['unix'] ."'".',0)">Hapus</a></td>
			</tr>';
			 $i++; }?>
		</tbody>
	</table>
